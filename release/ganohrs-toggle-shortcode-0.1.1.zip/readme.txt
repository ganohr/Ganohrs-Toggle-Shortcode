=== Ganohrs Toggle Shortcode ===
Contributors: Ganohr
Tags: Toggle,CSS,AMP
Donate link: http://amzn.asia/gw9HHbg
Requires at least: 4.0
Tested up to: 6.1.1
Requires PHP: 5.0
Stable tag: trunk
License: GPLv2
License URI: http://www.opensource.jp/gpl/gpl.ja.html

You can insert to WordPress that toggle-code for CSS-based / Or details Tag.

== Description ==
You can insert to WordPress that toggle-code for CSS-based Or details Tag.
簡単にCSSベース又はdetailsによる折りたたみコードをワードプレスへ追加できます。

Usage（使い方）:

[toggle title="title here" (optional)load="open / close" (optional)suffix="(empty) or 1 to 19"]
contents here
[/toggle]


== Frequently Asked Questions == 
Q. Can I use "details" tag to build toggles?
A. Yes you can! Please chose named "Details xxx" style.

Q. Can I use build toggle with "Old css based"?
A. Please chose not named "Details xxx" style.


== Screenshots ==
1. Easy to insert details-based toggle code.
2. If you wanna insert many toggles, then use "suffix".
3. "suffix" is useful. It because can change the css class.


== Changelog ==
0.1.1 Append Option "Output CSS When AMP", And any updated.
0.1.0 Append Option "Enqueue Type", And any updated.
0.0.3 Append "Details" styles, And any updated.
0.0.2 Change "readme.txt". And any updated.
0.0.1 New Release


== Upgrade Notice ==
